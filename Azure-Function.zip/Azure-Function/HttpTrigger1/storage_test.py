from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import os

# Azure Storage connection string
connection_string = "DefaultEndpointsProtocol=https;AccountName=azdevopsdevfuncpy;AccountKey=yk6QPxZ5J68/3GZtnWoOKnG2ix3eSxl/JVguwzm4u16ku1GoI8b7TZFgaJYxJIMa8moKx7mYFKfk+AStuBLhXA==;EndpointSuffix=core.windows.net"

# Initialize BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(connection_string)

# Name of the container where the file will be uploaded
container_name = "textfile"

# Name of the file to be uploaded
file_name = "tags.txt"

# Text content to be uploaded
text_content = "Hello, this is some text that will be uploaded to a blob!"

# Create a BlobClient to represent the file to be uploaded
blob_client = blob_service_client.get_blob_client(container=container_name, blob=file_name)

# Upload the text content to the storage container
blob_client.upload_blob(text_content, overwrite=True)

print(f"Text content uploaded to blob '{file_name}' in container '{container_name}' successfully.")

# Download the blob content
downloaded_blob = blob_client.download_blob()

# Read the content of the downloaded blob
downloaded_text = downloaded_blob.readall().decode("utf-8")

print(f"Downloaded text content: {downloaded_text}")

